  
def chromakey1(pic, bg):
  for p in getPixels(pic):
    x = getX(p)
    y = getY(p)
    if (getRed(p) + getBlue(p) < getGreen(p)):
      bgPixel = getPixel(bg, x, y)
      bgColor = getColor(bgPixel)
      setColor(p, bgColor)      
  
def chromakey2(pic, bg):
  for p in getPixels(pic):
    x = getX(p)
    y = getY(p)
    if distance(green, getColor(p)) < 10:
      bgPixel = getPixel(bg, x, y)
      bgColor = getColor(bgPixel)
      setColor(p, bgColor)      



#version 1: white on black
def edge(pic):
  maxX = getWidth(pic) - 1
  maxY = getHeight(pic) - 1
  for p in getPixels(pic):
    x = getX(p)
    y = getY(p)
    if x < maxX and y < maxY:
      p2 = getPixel(pic, x+1, y+1) #now get the other pixel
      sum = getRed(p) + getGreen(p) + getBlue(p)      
      sum2 = getRed(p2) + getGreen(p2) + getBlue(p2)
      diff = abs(sum - sum2)
      setColor(p, makeColor(diff, diff, diff))
      
#version 2: black drawing; helper function
def luminance(pixel):
  return (getRed(pixel) + getGreen(pixel) + getBlue(pixel))/3
  
def draw(pic):
  maxX = getWidth(pic) - 1
  maxY = getHeight(pic) - 1
  for p in getPixels(pic):
    x = getX(p)
    y = getY(p)
    if x < maxX and y < maxY:
      p2 = getPixel(pic, x+1, y+1)
      lum = luminance(p)      
      lum2 = luminance(p2)
      diff = abs(lum - lum2)
      if diff > 10:
        setColor(p, black)
      else:
        setColor(p, white)
        

 
# version 1
def posterize1(pic):
  for p in getPixels(pic):
    red = getRed(p)
    green = getGreen(p)
    blue = getBlue(p)
    
    if red < 128:
      setRed(p, 64)
    else:
      setRed(p, 192)

    if green < 128:
      setGreen(p, 64)
    else:
      setGreen(p, 192)    
    
    if blue < 128:
      setBlue(p, 64)
    else:
      setBlue(p, 192)    
 
# version 2 
def posterize2(pic):
  for p in getPixels(pic):
    red = getRed(p)
    green = getGreen(p)
    blue = getBlue(p)    
    reduceRed(p)
    reduceGreen(p)
    reduceBlue(p)    
 
def reduceRed(pixel):
  red = getRed(pixel)
  if red < 128:
    setRed(pixel, 64)
  else:
    setRed(pixel, 192)
    
def reduceGreen(pixel):
  green = getGreen(pixel)
  if green < 128:
    setGreen(pixel, 64)
  else:
    setGreen(pixel, 192)
    
def reduceBlue(pixel):
  blue = getBlue(pixel)
  if blue < 128:
    setBlue(pixel, 64)
  else:
    setBlue(pixel, 192)            
 
# version 3
def posterize3(pic):
  for p in getPixels(pic):
    setRed(p, getReducedColor(getRed(p)))
    setGreen(p, getReducedColor(getGreen(p))) 
    setBlue(p, getReducedColor(getBlue(p)))
    
#splits color range into 4 areas
def getReducedColor(color):
  if color < 128:  
    return 64
  else:
    return 192
    

#even better!
def posterize3(pic):
  for p in getPixels(pic):
    setRed(p, getReducedColor2(getRed(p)))
    setGreen(p, getReducedColor2(getGreen(p))) 
    setBlue(p, getReducedColor2(getBlue(p)))
    
def getReducedColor2(color):
  return color/128 * 128 + 64
 
 
 
def makeFrance1(pic):
  width = getWidth(pic) 
  point1 = width/3
  point2 = point1 * 2  
  for x in range(width):
    for y in range(getHeight(pic)):
      pixel = getPixel(pic, x, y)
      if x < point1:
        setRed(pixel, getRed(pixel) * 0.5)   
        setGreen(pixel, getGreen(pixel) * 0.5) 
      elif x < point2:
        setRed(pixel, getRed(pixel) * 1.5)
        setGreen(pixel, getGreen(pixel) * 1.5)
        setBlue(pixel, getBlue(pixel) * 1.5)  
      else:
        setGreen(pixel, getGreen(pixel) * 0.5)
        setBlue(pixel, getBlue(pixel) * 0.5)  
        
        
def makeFrance2(pic):
  width = getWidth(pic) 
  point1 = width/3
  point2 = point1 * 2  
  for x in range(width):
    for y in range(getHeight(pic)):
      p = getPixel(pic, x, y)
      if x < point1:
        increaseBlue(p)
      elif x < point2:
        increaseWhite(p)
      else:
        increaseRed(p)        
        
def makeNetherlands(picture):  
  pixels = getPixels(picture)
  point1 = len(pixels)/3
  point2 = point1 * 2  
  for i in range(len(pixels)):
    p = pixels[i]    
    if i < point1:
      increaseRed(p) 
    elif i >= point1 and i < point2:
      increaseWhite(p)
    else:
      increaseBlue(p)          

def increaseRed(pixel):
  setGreen(pixel, getGreen(pixel) * 0.5)
  setBlue(pixel, getBlue(pixel) * 0.5)   
  
def increaseWhite(pixel):
  setRed(pixel, getRed(pixel) * 1.5)
  setGreen(pixel, getGreen(pixel) * 1.5)
  setBlue(pixel, getBlue(pixel) * 1.5)  
  
def increaseBlue(pixel):
  setRed(pixel, getRed(pixel) * 0.5)   
  setGreen(pixel, getGreen(pixel) * 0.5) 
  

    
  

  
  
  
      
      