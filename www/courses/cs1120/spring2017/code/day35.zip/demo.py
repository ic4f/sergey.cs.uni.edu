from soundlib import *
import random
import time

#must use addLibPath('...path to directory with your library file - see pp.246-247')

def testBlending():
  c = makeSound('bassoon-c4.wav')
  e = makeSound('bassoon-e4.wav')
  g = makeSound('bassoon-g4.wav')
  chord = blendAnySoundsByMax(c, e, g)  
  explore(chord)
  
def coolerDemo(n):
  for i in range(n):
    play(coolDemo())
    time.sleep(3)

  
def coolDemo():
  w1 = makeSound('guzdial.wav')
  w2 = makeSound('is.wav')
  w3 = makeSound('a.wav')
  w4 = getAdjective()
  w5 = makeSound('and.wav')
  w6 = getAdjective()
  w7 = getNoun()
  
  normalize(w1)
  normalize(w2)
  normalize(w3)
  normalize(w4)
  normalize(w5)
  normalize(w6)
  normalize(w7)
  
  length1 = getLength(w1)
  length2 = getLength(w2)
  length3 = getLength(w3)
  length4 = getLength(w4)
  length5 = getLength(w5)
  length6 = getLength(w6)
  length7 = getLength(w7)
  length = length1 + length2 + length3 + length4 + length5 + length6 + length7  
  canvas = makeEmptySound(length)
  
  copy(w1, canvas, 0)
  copy(w2, canvas, length1)
  copy(w3, canvas, length1 + length2)
  copy(w4, canvas, length1 + length2 + length3)
  copy(w5, canvas, length1 + length2 + length3 + length4)
  copy(w6, canvas, length1 + length2 + length3 + length4 + length5)
  copy(w7, canvas, length1 + length2 + length3 + length4 + length5 + length6)
  
  return canvas
  
def getAdjective():
  filenames = ['great', 'clean', 'fun', 'frequent', 'fine']
  return getWord(filenames)
  
def getNoun():
  filenames = ['sun', 'rabbit', 'president', 'pig', 'horse', 'fly', 'concern', 'camel', 'computer']
  return getWord(filenames)

def getWord(words):
  index = random.randint(0,len(words)-1)
  filename = words[index] + '.wav'  
  return makeSound(filename)      