from media import *
    


#============================ MISC ============================#
#increase by factor
def increase(sound, factor): 
  for s in getSamples(sound):
    louder = getSampleValue(s) * factor
    setSampleValue(s, louder)
    
    
#decrease by factor
def decrease(sound, factor): 
  for s in getSamples(sound):
    softer = getSampleValue(s) / factor
    setSampleValue(s, softer)
    
    
#normalize sound
def normalize(sound):
  largest = 0
  for s in getSamples(sound):
    largest = max(largest, abs(getSampleValue(s)))
  multiplier = 32767.0 / largest  
  for s in getSamples(sound):
    louder = multiplier * getSampleValue(s)
    setSampleValue(s, louder)  
    
    
#fade-in
def fadeIn(sound):  
  length = getLength(sound)    
  fade_factor = 0
  fade_step = 1.0/length  
  for s in getSamples(sound):
    value = getSampleValue(s)  
    setSampleValue(s, value * fade_factor)
    fade_factor = fade_factor + fade_step  


#fade-out
def fadeOut(sound):  
  length = getLength(sound)    
  fade_factor = 1
  fade_step = 1.0/length  
  for s in getSamples(sound):
    value = getSampleValue(s)  
    setSampleValue(s, value * fade_factor)
    fade_factor = fade_factor - fade_step  


#reverse
def reverse(sound):
  samples1 = getSamples(sound)
  length = len(samples1)
  target = makeEmptySound(length) 
  samples2 = getSamples(target)   
  for i in range(length):
    s1 = samples1[i]
    s2 = samples2[length-i-1]
    value = getSampleValue(s1)
    setSampleValue(s2, value)
  return target


#============================ SPLICING ============================#
#extract sound from source sound
def clip(source, start, end):
  target = makeEmptySound(end - start)
  for i in range(start, end):
    v = getSampleValueAt(source, i)
    setSampleValueAt(target, i - start, v)
  return target


#copy source to target starting with offset  
def copy(source, target, offset):
  length = getLength(source)
  for i in range(0, length):
    v = getSampleValueAt(source, i)
    setSampleValueAt(target, i + offset, v)            
    
    
#============================ BLENDING ============================#    
#blend any number of sounds
#assume equal lengths
def blendSounds(*sounds):
  length = getLength(sounds[0])  
  blended = makeEmptySound(length)
  weight = 1.0 / len(sounds)
    
  for i in range(0, length):
    total = 0 
    for s in sounds:
      value = getSampleValueAt(s, i) * weight
      total += value
    setSampleValueAt(blended, i, total)
    
  normalize(blended)
  return blended   
    
      
#blend any number of sounds
#assume different lengths, use longest as length  
def blendAnySoundsByMax(*sounds):
  length = 0
  for s in sounds:
    length = max(length, getLength(s))

  blended = makeEmptySound(length)
  weight = 1.0 / len(sounds)
    
  for i in range(0, length):
    total = 0 
    for s in sounds:
      if i < getLength(s):
        value = getSampleValueAt(s, i) * weight
        total += value
    setSampleValueAt(blended, i, total)
    
  normalize(blended)
  return blended      
      
   
#blend any number of sounds
#assume different lengths, use shortest as length  
def blendAnySoundsByMin(*sounds): 
  length = sys.maxint
  for s in sounds:
    length = min(length, getLength(s))

  blended = makeEmptySound(length)
  weight = 1.0 / len(sounds)
    
  for i in range(0, length):
    total = 0 
    for s in sounds:
      if i < getLength(s):
        value = getSampleValueAt(s, i) * weight
        total += value
    setSampleValueAt(blended, i, total)
    
  normalize(blended)
  return blended     