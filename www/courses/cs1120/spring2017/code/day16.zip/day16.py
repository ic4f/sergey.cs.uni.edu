# version 1
def posterize1(pic):
  for p in getPixels(pic):
    red = getRed(p)
    green = getGreen(p)
    blue = getBlue(p)
    
    if red < 128:
      setRed(p, 64)
    else:
      setRed(p, 192)

    if green < 128:
      setGreen(p, 64)
    else:
      setGreen(p, 192)    
    
    if blue < 128:
      setBlue(p, 64)
    else:
      setBlue(p, 192)    
	  
 
# version 2 
def posterize2(pic):
  for p in getPixels(pic):
    red = getRed(p)
    green = getGreen(p)
    blue = getBlue(p)    
    reduceRed(p)
    reduceGreen(p)
    reduceBlue(p)    
 
def reduceRed(pixel):
  red = getRed(pixel)
  if red < 128:
    setRed(pixel, 64)
  else:
    setRed(pixel, 192)
    
def reduceGreen(pixel):
  green = getGreen(pixel)
  if green < 128:
    setGreen(pixel, 64)
  else:
    setGreen(pixel, 192)
    
def reduceBlue(pixel):
  blue = getBlue(pixel)
  if blue < 128:
    setBlue(pixel, 64)
  else:
    setBlue(pixel, 192) 
	
 
# version 3
def posterize3(pic):
  for p in getPixels(pic):
    setRed(p, getReducedColor(getRed(p)))
    setGreen(p, getReducedColor(getGreen(p))) 
    setBlue(p, getReducedColor(getBlue(p)))
    
#splits color range into 4 areas
def getReducedColor(color):
  if color < 128:  
    return 64
  else:
    return 192
    

#even better!
def posterize4(pic):
  for p in getPixels(pic):
    setRed(p, getReducedColor2(getRed(p)))
    setGreen(p, getReducedColor2(getGreen(p))) 
    setBlue(p, getReducedColor2(getBlue(p)))
    
def getReducedColor2(color):
  return color/128 * 128 + 64
 
 
#same idea applied to Netherlands		

#original:
def makeNetherlands1(picture):  
  pixels = getPixels(picture)
  point1 = len(pixels)/3
  point2 = point1 * 2
  
  for i in range(len(pixels)):
    pixel = pixels[i]    
    if i < point1:
      setBlue(pixel, getBlue(pixel) * 0.5)
      setGreen(pixel, getGreen(pixel) * 0.5)
    elif i >= point1 and i < point2:
      setRed(pixel, getRed(pixel) * 1.5)
      setGreen(pixel, getGreen(pixel) * 1.5)
      setBlue(pixel, getBlue(pixel) * 1.5)  
    else:
      setRed(pixel, getRed(pixel) * 0.5)
      setGreen(pixel, getGreen(pixel) * 0.5)  

#same approach applied:
def makeNetherlands2(picture):  
  pixels = getPixels(picture)
  point1 = len(pixels)/3
  point2 = point1 * 2  
  for i in range(len(pixels)):
    p = pixels[i]    
    if i < point1:
      increaseRed(p) 
    elif i >= point1 and i < point2:
      increaseWhite(p)
    else:
      increaseBlue(p)  


def increaseRed(pixel):
  setGreen(pixel, getGreen(pixel) * 0.5)
  setBlue(pixel, getBlue(pixel) * 0.5)   
  
def increaseWhite(pixel):
  setRed(pixel, getRed(pixel) * 1.5)
  setGreen(pixel, getGreen(pixel) * 1.5)
  setBlue(pixel, getBlue(pixel) * 1.5)  
  
def increaseBlue(pixel):
  setRed(pixel, getRed(pixel) * 0.5)   
  setGreen(pixel, getGreen(pixel) * 0.5) 

#now apply to sunset:  

#original
def makeSunset1(picture):
  for pixel in getPixels(picture):
    blueValue = getBlue(pixel)
    setBlue(pixel, blueValue * 0.5)
    greenValue = getGreen(pixel)
    setGreen(pixel, greenValue * 0.5)

#better:	
def makeSunset2(picture):
  for pixel in getPixels(picture):
    increaseRed(pixel)

#now with params
def makeSunsetP(picture):
  for pixel in getPixels(picture):
    increaseRedP(pixel, 0.7)
	
def increaseRedP(pixel, c):
  setGreen(pixel, getGreen(pixel) * c)
  setBlue(pixel, getBlue(pixel) * c)   

	
	
#now try france! Same colors.
def makeFrance2(pic):
  width = getWidth(pic) 
  point1 = width/3
  point2 = point1 * 2  
  for x in range(width):
    for y in range(getHeight(pic)):
      p = getPixel(pic, x, y)
      if x < point1:
        increaseBlue(p)
      elif x < point2:
        increaseWhite(p)
      else:
        increaseRed(p)  

		
		
		
def fixRedeye1(picture, x1, y1, x2, y2):
  for pixel in getPixels(picture):
    x = getX(pixel)
    y = getY(pixel)
    if x1 <= x <= x2 and y1 <= y <= y2:
      color = getColor(pixel)
      if distance(red, color) < 165:
        setColor(pixel, black) 
  repaint(picture)
    
        
def fixRedeye2(picture, x1, y1, x2, y2):
  for x in range(x1, x2):
    for y in range(y1, y2):
      pixel = getPixel(picture, x, y)
      color = getColor(pixel)
      if distance(red, color) < 165:
        setColor(pixel, black) 
  repaint(picture)           
  
  
#fixRedeye1(p1, 120, 90, 190, 106)
#fixRedeye1(p1, 330, 240, 500, 285)
