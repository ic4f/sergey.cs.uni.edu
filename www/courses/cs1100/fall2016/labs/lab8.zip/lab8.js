function showMessage(event) {
	var mouseX = event.clientX; //x coordinate of your mouse pointer
	var mouseY = event.clientY; //y coordinate of your mouse pointer	
	//write your code here....
	
}

/* this wires-up the showMessage function to the mouse move event:
	each time the mouse moves, the function is called */
document.querySelector("html").onmousemove = showMessage;