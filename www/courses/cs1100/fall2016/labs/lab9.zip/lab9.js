/*
this function takes no arguments and returns a string that specifies a color in this format: rgb(r, b, g)
where r, r, b, are the integer values of red, green, and blue (each  between 0 and 255). 
Red is rgb(255, 0, 0)
White is rgb(255, 255, 255)
Yellow is rgb(255, 204, 51)
and so on...
The values for red, green and blue are selected randomly, so the color is random. Enjoy!
*/
function getRandomColor() {
	var red  = parseInt(Math.random()*255);
	var green = parseInt(Math.random()*255);
	var blue = parseInt(Math.random()*255);
	var color = "rgb(" + red + ", " + green + ", " + blue + ")";
	return color;
}

