$(function() {

	/* ======================= PART 1 ======================= */	
	/*
	$("#profiles img").on("click", loadContent);	
	
	function loadContent(e) {
		var id = e.target.id;		
		var url = "content/" + id + ".html";
		
		$.get(url, function(response) {
			$("#ajaxcontent").html(response);
		});
	}
	*/

	/* ======================= PART 2 ======================= */
	/*
	$("#json-local").on("click", loadLocal);

	function loadLocal() {
		var url = "content/test.json";	
		$.getJSON(url, function(data) {
			$("#ajaxcontent").html(data.two);			
		});		
	}
	*/
		
	/* ======================= PART 3 ======================= */		
	/*
	$("#json-remote").on("click", loadRemote);
	
	function loadRemote() {		
		var key = "YOUR-API-KEY-GOES-HERE";
		var per_page = 20;

		//create variable and assign the base url + the ? character as the start of the query string
		var url = "https://api.flickr.com/services/rest/?";

		//now build the query string
		url += "method=flickr.photos.getRecent";
		url += "&api_key=" + key;
		url += "&per_page=" + per_page;
		url += "&format=json";
		url += "&nojsoncallback=1"
		
		//now get the data!
		$.getJSON(url, function(data) {
			var photos = data.photos.photo;
			var myimages = "";
			for (var i=0; i< photos.length; i++) {
				var ph = photos[i];								
				// template: https://c2.staticflickr.com/6/5164/5344061128_bb1dfe862d_q.jpg				
				var img = "<img src='https://c2.staticflickr.com/" + ph.farm + "/" + ph.server + "/" + ph.id + "_" + ph.secret + "_q.jpg'>";			
				var link = "<a href='https://www.flickr.com/photos/" + ph.owner + "/" + ph.id + "/'>" + img + "</a>";
				myimages += link;
			}
			$("#ajaxcontent").html(myimages);			
		});		
	}
	*/
});

//https://c2.staticflickr.com/6/5164/5344061128_bb1dfe862d_q.jpg
// { "id": "5344061128", "owner": "28414331@N02", "secret": "bb1dfe862d", "server": "5164", "farm": 6, "title": "Heading for San Francisco", "ispublic": 1, "isfriend": 0, "isfamily": 0 },


