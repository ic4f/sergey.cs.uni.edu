$(function() {
	
	//fade in everything
	$("body").hide().fadeIn(800);
	
	//handle mouseover
	$("#gallery img").on("mouseover", function() {		
		var $img = $(this);
		var $featured = $("#featured");
		var newSrc = $img.attr("src");
		
		$img.addClass("highlight");
		
		$featured.fadeOut(function() {
			$featured.fadeIn(1000);
			$featured.attr("src", newSrc);
		});
	});

	//handle moouseout
	$("#gallery img").on("mouseout", function() {
		$(this).removeClass("highlight");
	});
	
});
