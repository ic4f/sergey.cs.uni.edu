function showMessage(e) {
	var div = e.target;
	var p = div.children[0];
	var text = p.innerText;

	var messsageDiv = document.querySelector("#message");
	messsageDiv.innerText = text;	
}

function hideMessage() {
	var messsageDiv = document.querySelector("#message");
	messsageDiv.innerText = "";	
}

var divs = document.querySelectorAll("#places div");

for (var i=0; i<divs.length; i++) {
	var div = divs[i];
	div.addEventListener("mouseover", showMessage, false);
	div.addEventListener("mouseout", hideMessage, false);
}

