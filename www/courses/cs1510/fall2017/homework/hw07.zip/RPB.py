"""
File: RPB.py
Author: [Your name]	

Description:

Date last modified: 
 03/22/2017 (smd) -- provided modified template
 03/xx/2017 (xxx) -- you add comments here
----------------------------------------------------------------

--------------------------------------------------------------
INPUT: 	A poem from a local text (.txt) file. Each input
        file must follow this format: 
        ------------------------------
        | Poem Title (on line 1)
        | Author Name (one line 2)
        | <blank line>
        | Line #1 of the poem
        | Line #2 of the poem, etc.

OUTPUT: Prints messages to the console and produces new files
        that have deformed the poem in various ways.
        
        Backwards lines:
        The new filename will have "linesBackwards_" prepended to 
        the original filename. For example, an original input
        filename of "maryPoem.txt" will produce a new file called:
        "linesBackward_maryPoem.txt" (in the same directory).
           
        (you say more ...)

---------------------------------------------------------------
"""

# import these modules to help me
import string
import random

# Function: main
# Inputs: Nothing
# Outputs: Returns None, but creates 3 output files that
#          change the poemFileName
def main():
    """Runs all the functions that change the poem"""
    
    poemFileName = "maryPoem.txt"
    
    print ("")  # blank line
    
    #(1) 
    print ("(1) Starting Reading Lines Backwards ...\n")
    readingLinesBackwards( poemFileName )
    
    #(2)
    print ("(2) Starting Randomize Lines Backwards ...\n")
    randomizeLines( poemFileName )
    
    #(3)
    print ("(3) Starting Reading Words Backwards ...\n")
    readingWordsBackwards( poemFileName )
    
    print ("\nDone.\n")



# Function: readingLinesBackwards
# Inputs: poemFileName (must be a text file in the same
#         directory as this program
# Outputs: function returns None, but an output file is
#          written that is backwards with "backwards_"
#          prepended to the file name.

def readingLinesBackwards( poemFileName ):
    """Creates a new file with poemFileName written backwards"""

    print("\tThis function is almost done. To finish this function,\n" +\
          "\tplease write line numbers at the beginning of each\n" +\
          "\tline.  Then delete this print statement.\n")
    
    inputFile = open(poemFileName, 'r')
    
    newFileName = "linesBackwards_" + poemFileName
    outputFile = open(newFileName, 'w')

    # make an empty list to hold all the lines of a poem
    allLines = []

    #Get the title and author.  The .strip() method takes out the
    #newline at the end of the line.
    poemTitle  = inputFile.readline().strip()
    poemAuthor = inputFile.readline().strip()
    
    # skip blank line after the author name
    inputFile.readline()
    
    # now read each line of the poem and store the lines in a list
    for nextLine in inputFile:
        #nextLine = nextLine.strip()
        allLines.append(nextLine)
    
    # close the input (original) file
    inputFile.close()
    
    # now reverse the lines in the list
    allLines.reverse()
    
    # get the total number of lines in this poem
    totalLines = len(allLines)
    
    # print title and author
    outputFile.write("Lines Backwards\n")
    outputFile.write('Title: ' + poemTitle + '\n')
    outputFile.write('Author: ' + poemAuthor + '\n\n')
    
    # write the lines in the list to the file, one at a time.   
    for line in allLines:
        outputFile.write(line)
    # end of for loop

    print("\t" + newFileName +" created.\n")

    outputFile.close()
    return None


    
# Function: randomizeLines
# Inputs: [You write this]
# Outputs: [You write this]
def randomizeLines( poemFileName ):
    """You need to write the docstring"""
    
    inputFile = open(poemFileName, 'r')
    
    print ("\t You have to write the randomizeLines function \n")
    
    inputFile.close()
    
    

# Function: readingWordsBackwards
# Inputs: [You write this]
# Outputs: [You write tis]

def readingWordsBackwards( poemFileName ):
    """You need to write the docstring"""    
    inputFile = open(poemFileName, 'r')
    
    print ("\t You have to write the readingWordsBackwards function \n")

    inputFile.close()
    


# Function: remove_punctuation
# Inputs: A string (e.g., line of a poem)
# Outputs: A string with all the punctuation symbols removed

def remove_punctuation( s ):
    s_without_punct = ""
    for letter in s:
        if letter not in string.punctuation:
            s_without_punct += letter
            
    return s_without_punct  




    
